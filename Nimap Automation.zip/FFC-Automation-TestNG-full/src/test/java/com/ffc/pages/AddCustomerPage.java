package com.ffc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCustomerPage {
    private WebDriver driver;

    @FindBy(id = "customerName")
    private WebElement nameInput;

    @FindBy(id = "customerEmail")
    private WebElement emailInput;

    @FindBy(xpath = "//input[@name='name' or @id='name' or contains(@placeholder,'Name')]")
    private WebElement altNameInput;

    @FindBy(xpath = "//input[@name='email' or @id='email' or contains(@placeholder,'Email')]")
    private WebElement altEmailInput;

    @FindBy(id = "submitCustomer")
    private WebElement saveBtn;

    @FindBy(xpath = "//button[contains(.,'Save') or contains(.,'Submit') or contains(.,'Add')]")
    private WebElement altSaveBtn;

    @FindBy(xpath = "//div[contains(@class,'toast') or @role='alert' or contains(@class,'alert')]")
    private WebElement toast;

    public AddCustomerPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addCustomer(String name, String email) {
        try {
            nameInput.clear();
            nameInput.sendKeys(name);
        } catch (Exception e) {
            altNameInput.clear();
            altNameInput.sendKeys(name);
        }

        try {
            emailInput.clear();
            emailInput.sendKeys(email);
        } catch (Exception e) {
            altEmailInput.clear();
            altEmailInput.sendKeys(email);
        }

        try {
            saveBtn.click();
        } catch (Exception e) {
            altSaveBtn.click();
        }
    }

    public String getToastText() {
        try { return toast.getText(); } catch (Exception e) { return ""; }
    }
}
