package com.ffc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {
    private WebDriver driver;

    @FindBy(xpath = "//button[contains(.,'Punch In') or contains(.,'Punch-In') or contains(.,'Punchin') or contains(.,'Punch')]")
    private WebElement punchInButton;

    @FindBy(xpath = "//*[contains(@class,'toast') or contains(@class,'Toast') or contains(@class,'MuiAlert') or @role='alert']")
    private WebElement toastMsg;
    
    @FindBy(xpath = "//span[text()='Customers' or contains(.,'Customer') or contains(.,'Customers')]")
    private WebElement customersMenu;

    @FindBy(xpath = "//button[contains(.,'Add Customer') or contains(.,'New Customer') or contains(.,'Add')]")
    private WebElement addCustomerBtn;

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickPunchIn() {
        punchInButton.click();
    }

    public String getToastMessage() {
        try { return toastMsg.getText(); } catch (Exception e) { return ""; }
    }

    public void navigateToAddCustomer() {
        try {
            customersMenu.click();
        } catch (Exception e) {
            // ignore if already visible
        }
        addCustomerBtn.click();
    }
}
