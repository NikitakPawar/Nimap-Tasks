package com.ffc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    private WebDriver driver;

 // Email textbox
    @FindBy(xpath = "//input[@placeholder='Email Id / Mobile No']")
    private WebElement emailInput;

    // Password textbox
    @FindBy(xpath = "//input[@type='password']")
    private WebElement passwordInput;

    // Sign in button
    @FindBy(xpath = "//button[contains(text(),'Sign In')]")
    private WebElement loginButton;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void open(String url) {
        driver.get(url);
    }

    public void login(String email, String password) {
        emailInput.clear();
        emailInput.sendKeys(email);
        passwordInput.clear();
        passwordInput.sendKeys(password);
        loginButton.click();
    }
}
