package com.ffc.tests;

import com.ffc.pages.AddCustomerPage;
import com.ffc.pages.DashboardPage;
import com.ffc.pages.LoginPage;
import com.ffc.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddCustomerTest extends BaseTest {

    @DataProvider(name = "customerData")
    public Object[][] customerData() {
        return new Object[][]{
                {"Amit Sharma", "amit.sharma+test1@example.com"},
                {"Pooja Rane", "pooja.rane+test2@example.com"}
        };
    }

    @Test(dataProvider = "customerData")
    public void addCustomer(String name, String email) throws InterruptedException {
        LoginPage lp = new LoginPage(driver);
        lp.login(ConfigReader.get("username"), ConfigReader.get("password"));

        DashboardPage dp = new DashboardPage(driver);
        dp.navigateToAddCustomer();

        AddCustomerPage ap = new AddCustomerPage(driver);
        ap.addCustomer(name, email);

        Thread.sleep(1500);

        String toast = ap.getToastText();
        Assert.assertFalse(toast.isEmpty(), "No toast after adding customer");
        Assert.assertTrue(toast.toLowerCase().contains("customer") || toast.toLowerCase().contains("added") || toast.toLowerCase().contains("success"),
                "Unexpected add-customer toast: " + toast);
    }
}
