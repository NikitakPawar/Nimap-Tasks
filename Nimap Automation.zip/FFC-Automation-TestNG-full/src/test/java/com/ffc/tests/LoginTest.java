package com.ffc.tests;

import com.ffc.pages.LoginPage;
import com.ffc.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][]{
                {ConfigReader.get("username"), ConfigReader.get("password")}
        };
    }

    @Test(dataProvider = "loginData")
    public void loginValidation(String username, String password) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(username, password);

        String current = driver.getCurrentUrl();
        Assert.assertTrue(current.toLowerCase().contains("dashboard") || current.toLowerCase().contains("home") || current.toLowerCase().contains("admin"),
                "Login likely failed - current URL: " + current);
    }
}
