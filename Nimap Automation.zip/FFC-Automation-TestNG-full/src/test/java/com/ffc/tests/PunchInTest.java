package com.ffc.tests;

import com.ffc.pages.DashboardPage;
import com.ffc.pages.LoginPage;
import com.ffc.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PunchInTest extends BaseTest {

    @Test
    public void verifyPunchInToast() throws InterruptedException {
        LoginPage lp = new LoginPage(driver);
        lp.login(ConfigReader.get("username"), ConfigReader.get("password"));

        DashboardPage dp = new DashboardPage(driver);
        dp.clickPunchIn();

        Thread.sleep(1500);

        String toast = dp.getToastMessage();
        Assert.assertFalse(toast.isEmpty(), "No toast appeared after Punch In");
        Assert.assertTrue(toast.toLowerCase().contains("punch") || toast.toLowerCase().contains("success") || toast.toLowerCase().contains("in"),
                "Unexpected punch-in toast: " + toast);
    }
}
